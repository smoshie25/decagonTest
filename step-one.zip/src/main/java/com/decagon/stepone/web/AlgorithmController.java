package com.decagon.stepone.web;

import com.decagon.stepone.model.DataItem;
import com.decagon.stepone.model.UserResponse;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = "/algorithm")
public class AlgorithmController {

    public static final String uri = "https://jsonmock.hackerrank.com/api/article_users/search?page=";

    @RequestMapping(method = RequestMethod.GET,path = "/getUsername/{threshold}")
    public static List<String> getUsernames(@PathVariable(value = "threshold") int threshold) {

        List<DataItem> dataItems = getDataItems();

        Collections.sort(dataItems, Comparator.comparing(DataItem::getSubmission_count).reversed());

        dataItems.retainAll(dataItems.subList(0,threshold));

        return  dataItems.stream().map(dataItem -> dataItem.getUsername() ).collect(Collectors.toList());
    }

    @RequestMapping(method = RequestMethod.GET,path = "/getUsernameWithHighestCommentCount")
    public static String getUsernameWithHighestCommentCount(){

        List<DataItem> dataItems = getDataItems();

        Collections.sort(dataItems, Comparator.comparing(DataItem::getComment_count).reversed());


        return  dataItems.get(0).getUsername();
    }

    @RequestMapping(method = RequestMethod.GET,path = "/getUsernamesSortedByRecordDate/{threshold}")
    public static List<String> getUsernamesSortedByRecordDate(@PathVariable(value = "threshold") int threshold) {

        List<DataItem> dataItems = getDataItems();

        Collections.sort(dataItems, Comparator.comparing(DataItem::getUpdated_at));

        dataItems.retainAll(dataItems.subList(0,threshold));

        return  dataItems.stream().map(dataItem -> dataItem.getUsername() ).collect(Collectors.toList());
    }

    protected AlgorithmController(){

    }

    public static List<DataItem> getDataItems(){
        List<DataItem> dataItems = new ArrayList<>();

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<UserResponse> responseEntity = restTemplate.exchange(
                uri+"1",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<UserResponse>() {
                });
        UserResponse userResponse = responseEntity.getBody();
        ResponseEntity<UserResponse> responseEntity2 = restTemplate.exchange(
                uri+"2",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<UserResponse>() {
                });
        UserResponse userResponse2 = responseEntity2.getBody();

        dataItems.addAll(userResponse.getData());
        dataItems.addAll(userResponse2.getData());

        return dataItems;
    }

}
