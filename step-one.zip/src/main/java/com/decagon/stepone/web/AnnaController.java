package com.decagon.stepone.web;

import com.decagon.stepone.model.Wash;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/anna")
public class AnnaController {

    @RequestMapping(method = RequestMethod.POST,path = "/wash")
    public static int wash(@RequestBody @Validated Wash wash) {

        int washingMachineCapacity = wash.getNoOfWashes();
        int pairs = 1;

        int [] unpairedCleanSocks = wash.getCleanPile();



        if(washingMachineCapacity<1){
            return pairs;
        }


        for (int sock: wash.getDirtyPile()
        ) {
            for (int coloured : unpairedCleanSocks
                 ) {
                if(sock == coloured){
                    if(washingMachineCapacity>0)
                    pairs ++;
                    washingMachineCapacity--;
                }
            }
        }


        return pairs;
    }
}
