package com.decagon.stepone.model;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

public class DataItem{

	@SerializedName("comment_count")
	private int comment_count;

	@SerializedName("submitted")
	private int submitted;

	@SerializedName("updated_at")
	private Date updated_at;

	@SerializedName("submission_count")
	private int submission_count;

	@SerializedName("about")
	private String about;

	@SerializedName("created_at")
	private int createdAt;

	@SerializedName("id")
	private int id;

	@SerializedName("username")
	private String username;

	public int getComment_count(){
		return comment_count;
	}

	public int getSubmitted(){
		return submitted;
	}

	public Date getUpdated_at(){
		return updated_at;
	}

	public int getSubmission_count(){
		return submission_count;
	}

	public String getAbout(){
		return about;
	}

	public int getCreatedAt(){
		return createdAt;
	}

	public int getId(){
		return id;
	}

	public String getUsername(){
		return username;
	}
}