package com.decagon.stepone.model;

public class Wash {
    int noOfWashes;
    int cleanPile[];
    int dirtyPile[];

    public int getNoOfWashes() {
        return noOfWashes;
    }

    public void setNoOfWashes(int noOfWashes) {
        this.noOfWashes = noOfWashes;
    }

    public int[] getCleanPile() {
        return cleanPile;
    }

    public void setCleanPile(int[] cleanPile) {
        this.cleanPile = cleanPile;
    }

    public int[] getDirtyPile() {
        return dirtyPile;
    }

    public void setDirtyPile(int[] dirtyPile) {
        this.dirtyPile = dirtyPile;
    }
}
